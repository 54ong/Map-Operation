﻿namespace MapOperation
{
    partial class Form1
    {
        /// <summary>
        /// 必需的设计器变量。
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// 清理所有正在使用的资源。
        /// </summary>
        /// <param name="disposing">如果应释放托管资源，为 true；否则为 false。</param>


        #region Windows 窗体设计器生成的代码

        /// <summary>
        /// 设计器支持所需的方法 - 不要
        /// 使用代码编辑器修改此方法的内容。
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.btnZoomIn = new System.Windows.Forms.Button();
            this.btnZoomOut = new System.Windows.Forms.Button();
            this.btnZoomFree = new System.Windows.Forms.Button();
            this.btnPan = new System.Windows.Forms.Button();
            this.btnViewEntire = new System.Windows.Forms.Button();
            this.openFileDialog1 = new System.Windows.Forms.OpenFileDialog();
            this.label1 = new System.Windows.Forms.Label();
            this.tbmapname = new System.Windows.Forms.TextBox();
            this.label2 = new System.Windows.Forms.Label();
            this.tbdbs = new System.Windows.Forms.TextBox();
            this.btnopenmap = new System.Windows.Forms.Button();
            this.btnReset = new System.Windows.Forms.Button();
            this.mapControl1 = new SuperMap.UI.MapControl();
            this.workspace1 = new SuperMap.Data.Workspace(this.components);
            this.SuspendLayout();
            // 
            // btnZoomIn
            // 
            this.btnZoomIn.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.btnZoomIn.Location = new System.Drawing.Point(168, 18);
            this.btnZoomIn.Margin = new System.Windows.Forms.Padding(4);
            this.btnZoomIn.Name = "btnZoomIn";
            this.btnZoomIn.Size = new System.Drawing.Size(129, 37);
            this.btnZoomIn.TabIndex = 2;
            this.btnZoomIn.Text = "放大地图";
            this.btnZoomIn.UseVisualStyleBackColor = false;
            this.btnZoomIn.Click += new System.EventHandler(this.btnZoomIn_Click);
            // 
            // btnZoomOut
            // 
            this.btnZoomOut.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.btnZoomOut.Location = new System.Drawing.Point(321, 18);
            this.btnZoomOut.Margin = new System.Windows.Forms.Padding(4);
            this.btnZoomOut.Name = "btnZoomOut";
            this.btnZoomOut.Size = new System.Drawing.Size(129, 37);
            this.btnZoomOut.TabIndex = 3;
            this.btnZoomOut.Text = "缩小地图";
            this.btnZoomOut.UseVisualStyleBackColor = false;
            this.btnZoomOut.Click += new System.EventHandler(this.btnZoomOut_Click);
            // 
            // btnZoomFree
            // 
            this.btnZoomFree.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.btnZoomFree.Location = new System.Drawing.Point(483, 18);
            this.btnZoomFree.Margin = new System.Windows.Forms.Padding(4);
            this.btnZoomFree.Name = "btnZoomFree";
            this.btnZoomFree.Size = new System.Drawing.Size(129, 37);
            this.btnZoomFree.TabIndex = 4;
            this.btnZoomFree.Text = "自由缩放";
            this.btnZoomFree.UseVisualStyleBackColor = false;
            this.btnZoomFree.Click += new System.EventHandler(this.btnZoomFree_Click);
            // 
            // btnPan
            // 
            this.btnPan.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.btnPan.Location = new System.Drawing.Point(638, 18);
            this.btnPan.Margin = new System.Windows.Forms.Padding(4);
            this.btnPan.Name = "btnPan";
            this.btnPan.Size = new System.Drawing.Size(129, 37);
            this.btnPan.TabIndex = 5;
            this.btnPan.Text = "平移地图";
            this.btnPan.UseVisualStyleBackColor = false;
            this.btnPan.Click += new System.EventHandler(this.btnZoomPan_Click);
            // 
            // btnViewEntire
            // 
            this.btnViewEntire.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.btnViewEntire.Location = new System.Drawing.Point(13, 18);
            this.btnViewEntire.Margin = new System.Windows.Forms.Padding(4);
            this.btnViewEntire.Name = "btnViewEntire";
            this.btnViewEntire.Size = new System.Drawing.Size(128, 37);
            this.btnViewEntire.TabIndex = 6;
            this.btnViewEntire.Text = "地图复位";
            this.btnViewEntire.UseVisualStyleBackColor = false;
            this.btnViewEntire.Click += new System.EventHandler(this.btnViewEntire_Click);
            // 
            // openFileDialog1
            // 
            this.openFileDialog1.FileName = "openFileDialog1";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.label1.Font = new System.Drawing.Font("微软雅黑", 16F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.label1.Location = new System.Drawing.Point(33, 453);
            this.label1.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(101, 30);
            this.label1.TabIndex = 7;
            this.label1.Text = "地图名：";
            // 
            // tbmapname
            // 
            this.tbmapname.BackColor = System.Drawing.SystemColors.MenuHighlight;
            this.tbmapname.Location = new System.Drawing.Point(142, 453);
            this.tbmapname.Margin = new System.Windows.Forms.Padding(4);
            this.tbmapname.Multiline = true;
            this.tbmapname.Name = "tbmapname";
            this.tbmapname.Size = new System.Drawing.Size(192, 39);
            this.tbmapname.TabIndex = 8;
            this.tbmapname.Text = "在这里输入地图名";
            this.tbmapname.MouseClick += new System.Windows.Forms.MouseEventHandler(this.tbmapname_MouseClick);
            this.tbmapname.Leave += new System.EventHandler(this.tbmapname_Leave);
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.label2.Font = new System.Drawing.Font("微软雅黑", 16F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.label2.Location = new System.Drawing.Point(33, 505);
            this.label2.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(101, 30);
            this.label2.TabIndex = 10;
            this.label2.Text = "数据源：";
            // 
            // tbdbs
            // 
            this.tbdbs.BackColor = System.Drawing.SystemColors.Highlight;
            this.tbdbs.Location = new System.Drawing.Point(142, 507);
            this.tbdbs.Name = "tbdbs";
            this.tbdbs.ReadOnly = true;
            this.tbdbs.Size = new System.Drawing.Size(192, 34);
            this.tbdbs.TabIndex = 11;
            this.tbdbs.Text = "点击此处选择数据源";
            this.tbdbs.MouseClick += new System.Windows.Forms.MouseEventHandler(this.tbdbs_MouseClick);
            // 
            // btnopenmap
            // 
            this.btnopenmap.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.btnopenmap.Location = new System.Drawing.Point(402, 466);
            this.btnopenmap.Name = "btnopenmap";
            this.btnopenmap.Size = new System.Drawing.Size(125, 66);
            this.btnopenmap.TabIndex = 12;
            this.btnopenmap.Text = "打开地图";
            this.btnopenmap.UseVisualStyleBackColor = false;
            this.btnopenmap.Click += new System.EventHandler(this.btnopenmap_Click_1);
            // 
            // btnReset
            // 
            this.btnReset.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.btnReset.Location = new System.Drawing.Point(556, 466);
            this.btnReset.Name = "btnReset";
            this.btnReset.Size = new System.Drawing.Size(125, 66);
            this.btnReset.TabIndex = 13;
            this.btnReset.Text = "清除地图";
            this.btnReset.UseVisualStyleBackColor = false;
            this.btnReset.Click += new System.EventHandler(this.btnReset_Click);
            // 
            // mapControl1
            // 
            this.mapControl1.Action = SuperMap.UI.Action.Select2;
            this.mapControl1.BackColor = System.Drawing.SystemColors.ButtonHighlight;
            this.mapControl1.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.mapControl1.InteractionMode = SuperMap.UI.InteractionMode.Default;
            this.mapControl1.IsActionPrior = true;
            this.mapControl1.IsCursorCustomized = false;
            this.mapControl1.IsGlobalBrowsing = false;
            this.mapControl1.IsWaitCursorEnabled = true;
            this.mapControl1.Location = new System.Drawing.Point(122, 109);
            this.mapControl1.Margin = new System.Windows.Forms.Padding(48, 22, 48, 22);
            this.mapControl1.MarginPanEnabled = true;
            this.mapControl1.MarginPanPercent = 0.5D;
            this.mapControl1.Name = "mapControl1";
            this.mapControl1.RefreshAtTracked = true;
            this.mapControl1.RefreshInInvalidArea = false;
            this.mapControl1.RollingWheelWithoutDelay = false;
            this.mapControl1.SelectionMode = SuperMap.UI.SelectionMode.ContainInnerPoint;
            this.mapControl1.SelectionPixelTolerance = 0;
            this.mapControl1.Size = new System.Drawing.Size(522, 298);
            this.mapControl1.TabIndex = 14;
            this.mapControl1.TrackMode = SuperMap.UI.TrackMode.Edit;
            // 
            // workspace1
            // 
            this.workspace1.Caption = "UntitledWorkspace";
            this.workspace1.Description = "";
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(12F, 27F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(788, 553);
            this.Controls.Add(this.mapControl1);
            this.Controls.Add(this.btnReset);
            this.Controls.Add(this.btnopenmap);
            this.Controls.Add(this.tbdbs);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.tbmapname);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.btnViewEntire);
            this.Controls.Add(this.btnPan);
            this.Controls.Add(this.btnZoomFree);
            this.Controls.Add(this.btnZoomOut);
            this.Controls.Add(this.btnZoomIn);
            this.Font = new System.Drawing.Font("微软雅黑", 15F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.Margin = new System.Windows.Forms.Padding(4);
            this.Name = "Form1";
            this.Text = "地图基础操作";
            this.FormClosing += new System.Windows.Forms.FormClosingEventHandler(this.Form1_FormClosing);
            this.Load += new System.EventHandler(this.Form1_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion


        private System.Windows.Forms.Button btnZoomIn;
        private System.Windows.Forms.Button btnZoomOut;
        private System.Windows.Forms.Button btnZoomFree;
        private System.Windows.Forms.Button btnPan;
        private System.Windows.Forms.Button btnViewEntire;
        private System.Windows.Forms.OpenFileDialog openFileDialog1;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.TextBox tbmapname;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.TextBox tbdbs;
        private System.Windows.Forms.Button btnopenmap;
        private System.Windows.Forms.Button btnReset;
        private SuperMap.UI.MapControl mapControl1;
        private SuperMap.Data.Workspace workspace1;
    }
}

