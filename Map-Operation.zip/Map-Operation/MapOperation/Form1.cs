﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using SuperMap.Data;
using SuperMap.Mapping;
using SuperMap.UI;

namespace MapOperation
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void mapControl1_Load(object sender, EventArgs e)
        {

        }

        #region 按钮代码
        
        /// <summary>
        /// 放大地图
        /// </summary>   
        private void btnZoomIn_Click(object sender, EventArgs e)
        {
            //-----------------添加以下代码，放大地图-----------------//
            mapControl1.Action = SuperMap.UI.Action.ZoomIn;
        }

        /// <summary>
        /// 缩小地图
        /// </summary>
        private void btnZoomOut_Click(object sender, EventArgs e)
        {
            //-----------------添加以下代码，缩小地图----------------//
            mapControl1.Action = SuperMap.UI.Action.ZoomOut;
        }
        /// <summary>
        /// 自由缩放
        /// </summary>    
        private void btnZoomFree_Click(object sender, EventArgs e)
        {
            //-----------------添加以下代码，自由缩放---------------//
            mapControl1.Action = SuperMap.UI.Action.ZoomFree;
        }
        /// <summary>
        /// 平移地图
        /// </summary> 
        private void btnZoomPan_Click(object sender, EventArgs e)
        {
            //-----------------添加以下代码，平移地图---------------//
            mapControl1.Action = SuperMap.UI.Action.Pan;
        }
        /// <summary>
        /// 地图复位
        /// </summary>
        private void btnViewEntire_Click(object sender, EventArgs e)
        {
            //-----------------添加以下代码，地图复位---------------//
            mapControl1.Map.ViewEntire();
        }
        /// <summary>
        /// 清除地图
        /// </summary>
        private void btnReset_Click(object sender, EventArgs e)
        {
            //判断是否有已经打开的地图
            if (workspace1.Maps.Count != 0)
            {
                //弹出对话框
                MessageBoxButtons messButton = MessageBoxButtons.OKCancel;
                DialogResult dr = MessageBox.Show("你想要清除当前地图吗？", "清除地图", messButton);
                if (dr == DialogResult.OK)
                {
                    //清空地图和文本框
                    tbdbs.Text = "点击此处选择数据源";
                    tbmapname.Text = "在这里输入地图名";
                    mapControl1.Map.Close();
                    workspace1.Close();
                    mapControl1.Map.Refresh();
                }

            }
            else
            {
                MessageBox.Show("没有地图需要清除");
            }
        }
        /// <summary>
        /// 打开地图
        /// </summary>
        private void btnopenmap_Click_1(object sender, EventArgs e)
        {
            //判断是否有已经打开的地图
            if (workspace1.Maps.Count != 0)
                MessageBox.Show("请先清除当前的地图");
            else
            {
                //验证输入
                if (tbmapname.Text == "在这里输入地图名" || tbdbs.Text == "点击此处选择数据源")
                {
                    MessageBox.Show("请先完整输入信息");
                }
                else
                {
                    try
                    {
                        //-----------------添加以下代码，打开地图-----------------//
                        //构造工作空间连接对象
                        WorkspaceConnectionInfo workspaceConnectionInfo = new WorkspaceConnectionInfo();
                        //设置工作空间属性
                        workspaceConnectionInfo.Server = @tbdbs.Text;
                        //workspaceConnectionInfo.Server = @"F:\SuperMap\SampleData\World\World.smwu";
                        workspaceConnectionInfo.Type = WorkspaceType.SMWU;
                        //打开工作空间
                        workspace1.Open(workspaceConnectionInfo);
                        //打开地图
                        mapControl1.Map.Open(tbmapname.Text);
                        // mapControl1.Map.Open("World_Google");
                        //地图显示控制
                        mapControl1.Map.ViewEntire();
                    }
                    catch
                    {
                        MessageBox.Show("地图名和数据源不匹配");
                    }
                }
            }
        }
        #endregion

        #region 文本框代码
        /// <summary>
        /// 显示数据源和打开浏览窗口
        /// </summary>
        private void tbdbs_MouseClick(object sender, MouseEventArgs e)
        {
            //打开浏览窗口
            if (openFileDialog1.ShowDialog() == DialogResult.OK)
            {
                //将数据源url显示在文本框中
                tbdbs.Text = openFileDialog1.FileName;
            }

        }
        /// <summary>
        /// 地图名文本框的初始化
        /// </summary>
        private void tbmapname_MouseClick(object sender, MouseEventArgs e)
        {
            if (tbmapname.Text == "在这里输入地图名")
                tbmapname.Text = "";
        }


        /// <summary>
        /// 地图名文本框的初始化
        /// </summary>
        private void tbmapname_Leave(object sender, EventArgs e)
        {
            if (tbmapname.Text == "")
                tbmapname.Text = "在这里输入地图名";
        }
        #endregion
        private void Form1_Load(object sender, EventArgs e)
        {
            //先将焦点集中于地图名文本框，提升用户体验
            tbmapname.Focus();
            //地图与工作空间关联
            mapControl1.Map.Workspace = workspace1;


        }

        private void Form1_FormClosing(object sender, FormClosingEventArgs e)
        {
            //添加以下代码，断开控件连接
            mapControl1.Dispose();
            workspace1.Dispose();
        }





















    }
}
