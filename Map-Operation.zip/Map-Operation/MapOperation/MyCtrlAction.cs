using System;
using System.Collections.Generic;
using System.Text;
using System.Windows.Forms;
using SuperMap.Desktop;

namespace MapOperation
{
    class MyCtrlAction : CtrlAction
    {
        public MyCtrlAction(IBaseItem caller)
            : base(caller)
        {

        }

        override public void Run()
        {
            //To do your work.
            //Example:
            
            //��������
            Form1 form = new Form1();
            form.Show();
           
            IBaseItem baseItem = this.Caller;
            if (baseItem != null)
            {
                String itemType = baseItem.GetType().ToString().Replace("SuperMap.Desktop.", "");
                
            }

        }
    }
}
